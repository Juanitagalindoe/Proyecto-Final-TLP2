import axios from "axios";

const API = "http://localhost:8080/api";

export const getAllPosts = () =>
  axios.get(`${API}/posts`);

export const createPost = (data) =>
  axios.post(`${API}/posts`, data);

export const likePost = (postId, usuarioId) =>
  axios.post(`${API}/likes`, { postId, usuarioId });

export const getPostById = (id) =>
  axios.get(`${API}/posts/${id}`);

export const addComment = (data) =>
  axios.post(`${API}/comments`, data);
