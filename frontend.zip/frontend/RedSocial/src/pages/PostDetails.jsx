import { useParams } from "react-router-dom";
import { useState, useEffect, useContext } from "react";
import { getPostById, addComment } from "../services/postService";
import { AuthContext } from "../context/AuthContext";

export default function PostDetails() {
  const { id } = useParams();
  const { user } = useContext(AuthContext);

  const [post, setPost] = useState(null);
  const [contenido, setContenido] = useState("");

  const load = async () => {
    const res = await getPostById(id);
    setPost(res.data);
  };

  const sendComment = async () => {
    await addComment({
      contenido,
      postId: id,
      usuarioId: user.id,
    });
    setContenido("");
    load();
  };

  useEffect(() => {
    load();
  }, []);

  if (!post) return <p>Cargando...</p>;

  return (
    <div style={{ width: "600px", margin: "0 auto", padding: "20px" }}>
      <h2>{post.caption}</h2>
      {post.imagen && <img src={post.imagen} style={{ width: "100%", borderRadius: "12px" }} />}

      <h3 style={{ marginTop: "20px" }}>Comentarios</h3>
      {post.comentarios.map((c, i) => (
        <p key={i}><strong>{c.usuario?.nombre}:</strong> {c.contenido}</p>
      ))}

      <textarea
        value={contenido}
        onChange={(e) => setContenido(e.target.value)}
        placeholder="Escribe un comentario..."
        style={{ width: "100%", marginTop: "12px", padding: "10px" }}
      />

      <button onClick={sendComment} style={{ marginTop: "10px" }}>
        Comentar
      </button>
    </div>
  );
}
