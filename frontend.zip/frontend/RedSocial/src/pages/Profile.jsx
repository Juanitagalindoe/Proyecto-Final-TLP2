import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

export default function Profile() {
  const { user } = useContext(AuthContext);

  if (!user) return <p>No has iniciado sesión.</p>;

  return (
    <div style={{ padding: "40px" }}>
      <h2>Mi Perfil</h2>
      <p><strong>Nombre:</strong> {user.nombre}</p>
      <p><strong>Correo:</strong> {user.correo}</p>
      <p><strong>Celular:</strong> {user.celular}</p>
    </div>
  );
}
