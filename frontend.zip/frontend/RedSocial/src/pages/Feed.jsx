import { useState, useEffect } from "react";
import { getAllPosts } from "../services/postService";
import PostCard from "../components/PostCard";
import NewPost from "../components/NewPost";

export default function Feed() {
  const [posts, setPosts] = useState([]);

  const loadPosts = async () => {
    const res = await getAllPosts();
    setPosts(res.data);
  };

  useEffect(() => {
    loadPosts();
  }, []);

  return (
    <div style={{ width: "600px", margin: "0 auto", padding: "20px" }}>
      <NewPost refresh={loadPosts} />

      {posts.map((p) => (
        <PostCard key={p.id} post={p} refresh={loadPosts} />
      ))}
    </div>
  );
}
