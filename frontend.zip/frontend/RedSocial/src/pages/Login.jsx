import { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import axios from "axios";
import "./Auth.css";

export default function Login() {
  const { login } = useContext(AuthContext);
  const [correo, setCorreo] = useState("");
  const [contrasena, setContrasena] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await axios.post("http://localhost:8080/api/auth/login", {
      correo,
      contrasena,
    });

    login(res.data);
  };

  return (
    <div className="auth-container">
      <h2>Iniciar Sesión</h2>

      <form onSubmit={handleSubmit}>
        <input placeholder="Correo" value={correo} onChange={(e) => setCorreo(e.target.value)} />
        <input type="password" placeholder="Contraseña" value={contrasena} onChange={(e) => setContrasena(e.target.value)} />
        <button>Ingresar</button>
      </form>
    </div>
  );
}
