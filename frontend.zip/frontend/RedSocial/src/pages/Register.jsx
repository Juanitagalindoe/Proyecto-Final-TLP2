import { useState } from "react";
import axios from "axios";
import "./Auth.css";

export default function Register() {
  const [form, setForm] = useState({
    nombre: "",
    apellido: "",
    correo: "",
    contrasena: "",
    celular: ""
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8080/api/auth/register", form);
    alert("Usuario registrado");
  };

  return (
    <div className="auth-container">
      <h2>Crear Cuenta</h2>

      <form onSubmit={handleSubmit}>
        {Object.keys(form).map((field) => (
          <input
            key={field}
            placeholder={field}
            value={form[field]}
            onChange={(e) => setForm({ ...form, [field]: e.target.value })}
          />
        ))}
        <button>Registrarse</button>
      </form>
    </div>
  );
}
