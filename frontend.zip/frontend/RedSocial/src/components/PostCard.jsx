import { Link } from "react-router-dom";
import { likePost } from "../services/postService";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import "./PostCard.css";

export default function PostCard({ post, refresh }) {
  const { user } = useContext(AuthContext);

  const handleLike = async () => {
    await likePost(post.id, user.id);
    refresh();
  };

  return (
    <div className="post-card">
      <h3>{post.caption}</h3>

      {post.imagen && (
        <img src={post.imagen} className="post-img" alt="post" />
      )}

      <div className="post-footer">
        <button onClick={handleLike}>❤️ {post.likes?.length}</button>
        <Link to={`/post/${post.id}`}>💬 {post.comentarios?.length} comentarios</Link>
      </div>
    </div>
  );
}
