import { useState, useContext } from "react";
import { createPost } from "../services/postService";
import { AuthContext } from "../context/AuthContext";
import "./NewPost.css";

export default function NewPost({ refresh }) {
  const { user } = useContext(AuthContext);
  const [caption, setCaption] = useState("");
  const [imagen, setImagen] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    await createPost({
      caption,
      usuarioId: user.id,
      imagen
    });
    setCaption("");
    setImagen("");
    refresh();
  };

  return (
    <div className="new-post">
      <form onSubmit={handleSubmit}>
        <textarea
          placeholder="¿Qué estás pensando?"
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
        />

        <input
          placeholder="URL de la imagen (opcional)"
          value={imagen}
          onChange={(e) => setImagen(e.target.value)}
        />

        <button>Publicar</button>
      </form>
    </div>
  );
}
